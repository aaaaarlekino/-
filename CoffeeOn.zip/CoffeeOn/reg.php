<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=`device-width`, initial-scale=1.0">
    <link rel="stylesheet" href="reg.css">
    <title>Document</title>
</head>
<body>
<form id="form" action="handler.php" method="post">
        <input class="input" type="email" placeholder="mail" id="mail" name="mail">
        <input class="input" type="password" placeholder="password" id="passowrd" name="password">
        <input id="btn" type="submit">
    </form>
</body>
</html>